package com.islamsaeed.newsmvvm;

public class Constants {

    public static final String API_KEY = "81919828d95c400eaa1c66e38c4b3110";
    public static final String LANGUAGE = "en";
}
